###################################################################
import sys
from PyQt5.QtWidgets import * # QtWidgets 윈도우 core 
from PyQt5 import uic
from PyQt5.QtGui import *
import os
import pandas as pd
import numpy as np
import re
import matplotlib.pyplot as plt
from wordcloud import WordCloud
#####################################################################




#####################################################################
# 문자열에서 특수문자 제거하는 정규화 함수
def clean_text(inputString):
    text_rmv = re.sub('[-=+,#/\?:^.@*\"※~ㆍ!』‘|\(\)\[\]`\'…》\”\“\’\'·]', ' ', inputString)
    return text_rmv
#####################################################################





########################################################################
# 특정 경로에 있는 csv 파일만 불러오기
path = "./search/"


# 워드 클라우드 자동 저장 함수
def wordCloudView():
    # listdir -> 현재 경로에 있는 모든 파일을 확인할 때
    file_list = os.listdir(path)
    fileList1 = [file for file in file_list if file.endswith('.csv')]
    
    # 여러 csv 파일을 자동병합해서 하나의 df로 불러오는 방법
    # 우선 비어있는 프레임 생성
    dfCsv = pd.DataFrame()
    for i in fileList1:
        data = pd.read_csv(path + i, encoding='utf-8')
        dfCsv = pd.concat([dfCsv, data]) # 붙이기(이렇게 붙이면 인덱스가 그대로 붙음)

    dfCsv = dfCsv.reset_index(drop = True) # 인덱스 초기화

    dfCsv = dfCsv.drop(['링크'], axis = 'columns')
    
    listCsv = dfCsv['제목'].astype(str).tolist()

    wordStr = " ".join(listCsv)

    wordStr = clean_text(wordStr)

    wc1 = WordCloud(
    font_path = "c:\Windows\fonts\malgun.ttf",
    stopwords = ['알리익스프레스','테무','중국','알리','쇼핑몰','중국에서','테무에서','질문','중국에','ㅠㅠ','되나요','샀는데','질문드립니다','및','오나요','ㅠ','있나요'],
    background_color = "white",
    width = 1200,
    height = 600,
    random_state = 40)

    wc1.generate(wordStr)

    wc1.to_file("search/word.png")

##################################################################







####################################################################
wordMain = uic.loadUiType("ui/ui_wordcloud.ui")[0]

class WordWin(QDialog, wordMain):

    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btn_close.clicked.connect(self.btn_close_clicked)
        self.btn_wc.clicked.connect(self.btn_wc_clicked)


    def showModal(self):
        return super().exec_()
    
    def btn_close_clicked(self):
        self.close()

    def btn_wc_clicked(self):
        wordCloudView()
        print("이미지가 저장되었습니다.")
        self.lb_img.setPixmap(QPixmap('./search/word.png'))
#######################################################################