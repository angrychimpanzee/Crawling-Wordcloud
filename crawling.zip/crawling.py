import sys
from PyQt5.QtWidgets import * # QtWidgets 윈도우 core 
from PyQt5 import uic
from crawling_naver import *
from PyQt5.QtGui import *
from random import *

formCrawling = uic.loadUiType("ui/ui_crawling.ui")[0]

class CrawlingWindow(QDialog, formCrawling):
    # 전역변수
    searchKin = ""


    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btn_close.clicked.connect(self.btn_close_clicked)
        self.btn_search.clicked.connect(self.btn_search_clicked)
        self.btn_save.clicked.connect(self.btn_save_clicked)
        self.btn_add.clicked.connect(self.btn_add_clicked)



    def showModal(self):
        return super().exec_()
    
    def btn_close_clicked(self):
        self.close()

    def btn_search_clicked(self):
        if self.le_search.text() == "":
            QMessageBox.about(self, "에러", "입력값이 존재하지 않습니다.")
            return
        
        naverClear()
        self.searchKin = self.le_search.text()

        # 검색 동작
        # search = input("검색어: ")
        for i in range(100):
            page = i + 1
            sList = naverKin(self.searchKin, page)
            print("#"*20 + " " +str(page) + "page " +"#"*20)
            
            print(sList)
            # 리스트뷰에 보여주기
            self.model = QStandardItemModel()
            for data in sList:
                self.model.appendRow(QStandardItem(data[0]))
            self.lv_search.setModel(self.model)
            time.sleep(randint(1,4)) # 블락 안당하게 랜덤으로 타임슬립 설정
            # time.sleep(1.5) # 블락 안당하게 랜덤으로 타임슬립 설정
    
    def btn_save_clicked(self):
        if self.searchKin == "":
            QMessageBox.about(self, "에러", "검색한 정보가 없습니다.")
            return
        
        # 파일저장
        saveKin(f'scv/{self.searchKin}')
        QMessageBox.about(self, "성공", "정보가 저장되었습니다.")
    
    def btn_add_clicked(self):
        # 리스트 뷰에 데이터 추가하기
        pass
