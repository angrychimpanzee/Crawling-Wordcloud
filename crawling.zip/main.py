import sys
from PyQt5.QtWidgets import * # QtWidgets 윈도우 core 
from PyQt5 import uic
from crawling import CrawlingWindow
from random import *
from word import WordWin

form_main = uic.loadUiType("ui/ui_main.ui")[0]

class MyWindow(QMainWindow, form_main):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btn_close.clicked.connect(self.btn_close_clicked)
        self.btn_crawling.clicked.connect(self.btn_crawling_clicked)
        self.btn_wordcloud.clicked.connect(self.btn_wordcloud_clicked)

    def btn_close_clicked(self):
        exit()
    def btn_crawling_clicked(self):
        crawlingWin = CrawlingWindow()
        crawlingWin.showModal()
    def btn_wordcloud_clicked(self):
        wordWin = WordWin()
        wordWin.showModal()  
app = QApplication(sys.argv)
window = MyWindow()
window.show()
app.exec_()

