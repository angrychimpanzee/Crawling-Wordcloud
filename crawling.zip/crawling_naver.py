################################################
# 네이버 자동 크롤링 프로그램
# 날짜: 2024-05-07
# lib: requests, selenium, beautifulsoup4
################################################



################################################
# 라이브러리 
import csv
from urllib.request import urlopen
from bs4 import BeautifulSoup as bs
from urllib.parse import quote_plus # url에서 특수문자 한글 변환
import requests
import codecs
import time
################################################




################################################
# csv 데이터 저장하기 위한 빈 리스트 생성
searchList = []

def naverClear():
    global searchList
    searchList = []
################################################





################################################
def naverKin(search, i):

    ################################################
    # # 검색어 변환
    # query = quote_plus(search)
    # print("검색어 변환: ", query)


    # url에서 정보 가져오기
    url = f"https://kin.naver.com/search/list.naver?query={quote_plus(search)}&page={i}"
    # print("url: ", url)
    ################################################






    ###############################################
    # 인터넷에서 정보 가져오기(requests)
    html = requests.get(url)
    # print(html)


    # 만약 응답코드 200이 아니면 종료
    if html.status_code == 200:
        htmlcode = html.text
        # print(htmlcode)

        # 선언
        soup = bs(htmlcode, 'html.parser')

        # <ul class="basic1"> 찾는 과정
        ul = soup.select_one('ul.basic1') # class는 .으로 바꿈

        # ul 내에서 li 추출
        titles = ul.select('li>dl>dt>a') #select_one : 하나만 추출 / select : 해당 항목 리스트로 전체 추출

        # 데이터 값 가져오기
        for title in titles:
            print(title.text)
            print(title.attrs['href'])  # 속성 중에 주소만 추출

            # 임시 공간에 저장 
            tmp = []
            tmp.append(title.text)
            tmp.append(title.attrs['href'])
            searchList.append(tmp)
        
    return searchList
    #################################################


# def naverKin end
####################################################



################################################
# 파일저장
def saveKin(search):

    #f = codecs.open(f'{search}.csv', 'w', encoding='cp949') # 엑셀파일에 한글형식으로 하려면 encoding='cp949' 추가해야함
    f = codecs.open(f'{search}.csv', 'w', encoding='UTF-8') # 엑셀파일에 한글형식으로 하려면 encoding='cp949' 추가해야함
    csvWriter = csv.writer(f)
    csvWriter.writerow(['제목', '링크']) # 판다스에서 쓰려면 헤더가 필요하므로 추가해야함

    for data in searchList:
        # 한줄씩 저장
        csvWriter.writerow(data)

    f.close()

# def daveKin end
################################################




################################################
# search = input("검색어: ")
# for i in range(10):
#     page = i + 1
#     naverKin(search, page)
#     print("#"*20 + " " +str(page) + "page " +"#"*20)
#     time.sleep(2)
